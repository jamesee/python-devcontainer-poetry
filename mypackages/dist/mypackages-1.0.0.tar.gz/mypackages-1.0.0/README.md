poetry new my-folder --src --name package1

python src

poetry build

poetry install

poetry run mycli

poetry run python src
