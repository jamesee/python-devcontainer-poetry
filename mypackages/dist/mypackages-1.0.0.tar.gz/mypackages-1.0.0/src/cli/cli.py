
from package1 import hello1
from package2 import hello2

def main():
    print(hello1())
    print(hello2())