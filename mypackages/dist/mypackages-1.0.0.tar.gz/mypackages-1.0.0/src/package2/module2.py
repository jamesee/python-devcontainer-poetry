def hello2():
    return f"Hello from hello2 " 